import { getStore } from '@netlify/blobs';

export default async (req) => {
  const store = getStore('turnos');
  if (req.method === 'GET') {
    const data = (await store.get('history', { type: 'json' })) || [];
    return Response.json(data);
  }
  if (req.method === 'POST') {
    let rec;
    try { rec = await req.json(); } catch { return new Response('bad json', { status: 400 }); }
    if (!rec || typeof rec !== 'object' || !rec.ts) return new Response('bad record', { status: 400 });
    const data = (await store.get('history', { type: 'json' })) || [];
    if (!data.some(h => h.ts === rec.ts)) {
      data.push(rec);
      data.sort((a, b) => a.ts - b.ts);
      await store.setJSON('history', data);
    }
    return Response.json({ ok: true, count: data.length });
  }
  if (req.method === 'DELETE') {
    const ts = Number(new URL(req.url).searchParams.get('ts'));
    if (!ts) return new Response('ts required', { status: 400 });
    const data = (await store.get('history', { type: 'json' })) || [];
    const next = data.filter(h => h.ts !== ts);
    await store.setJSON('history', next);
    return Response.json({ ok: true, removed: data.length - next.length, count: next.length });
  }
  return new Response('method not allowed', { status: 405 });
};

export const config = { path: '/api/turnos' };
